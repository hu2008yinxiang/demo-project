<?php

/**
 * @file
 * Contains \Drupal\Core\Path\AliasWhitelistInterface.
 */

namespace Drupal\Core\Path;

use Drupal\Core\Cache\CacheCollectorInterface;

interface AliasWhitelistInterface extends CacheCollectorInterface {}
